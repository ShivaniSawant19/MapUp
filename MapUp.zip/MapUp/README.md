<!-- install -->
npm install --save google-maps-react
npm install react-bootstrap bootstrap@5.1.3
npm install react-icons
npm install --save styled-components
npm install --save-dev @types/react-bootstrap @types/bootstrap
npm install --save react-bootstrap-validation
npm install react-router-dom@latest