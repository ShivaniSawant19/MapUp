import React from 'react';
import RegistrationForm from './RegistrationForm';
import Footer from './Footer';
import Navbar from './Home';

export default function Settings() {
  return (
   
<div>
  <Navbar />
  
  <RegistrationForm />
  
<Footer />
</div>

  )
}
