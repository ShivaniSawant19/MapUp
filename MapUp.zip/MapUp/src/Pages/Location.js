import React from "react";

import "../index.css";
import Navbar from "./Home";
import Footer from "./Footer";



function App() {
  return (
    <div className="App">
  
    <Navbar />
  
    <Footer />
    </div>
  );
}

export default App;